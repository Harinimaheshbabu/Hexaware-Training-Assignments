-- =====================================================================
-- Day 8 - CTEs, Window Functions and Transactions (MySQL 8.4 LTS)
-- Set 2 - Airline Seat Booking
-- File: ranking_report.sql
-- Run booking_transaction.sql first. If you did the Task 1 / Task 2
-- tests, run the RESET block at the end of that file so that there are
-- exactly 15 bookings (otherwise your output will have extra rows).
-- =====================================================================
USE airline_booking;

SELECT COUNT(*) AS total_bookings FROM bookings;   -- should be 15

-- ---------------------------------------------------------------------
-- TASK 3 - RANK and DENSE_RANK per flight
-- ---------------------------------------------------------------------
SELECT f.flight_no,
       p.passenger_name,
       b.fare,
       RANK()       OVER (PARTITION BY f.flight_id ORDER BY b.fare DESC) AS fare_rank,
       DENSE_RANK() OVER (PARTITION BY f.flight_id ORDER BY b.fare DESC) AS fare_dense_rank
FROM bookings b
INNER JOIN passengers p ON b.passenger_id = p.passenger_id
INNER JOIN seats s      ON b.seat_id = s.seat_id
INNER JOIN flights f    ON s.flight_id = f.flight_id
ORDER BY f.flight_no, b.fare DESC, b.booking_id;

-- ---------------------------------------------------------------------
-- TASK 4 - CTE with rank and running revenue total
-- ---------------------------------------------------------------------
WITH flight_bookings AS (
    SELECT f.flight_no,
           p.passenger_name,
           b.booking_id,
           b.fare,
           RANK() OVER (PARTITION BY f.flight_id ORDER BY b.fare DESC) AS fare_rank
    FROM bookings b
    INNER JOIN passengers p ON b.passenger_id = p.passenger_id
    INNER JOIN seats s      ON b.seat_id = s.seat_id
    INNER JOIN flights f    ON s.flight_id = f.flight_id
)
SELECT flight_no,
       passenger_name,
       fare,
       fare_rank,
       SUM(fare) OVER (PARTITION BY flight_no ORDER BY booking_id) AS running_revenue
FROM flight_bookings
ORDER BY flight_no, booking_id;

-- ---------------------------------------------------------------------
-- TASK 5 - Correlated subquery: fare above the average of the same flight
-- ---------------------------------------------------------------------
SELECT p.passenger_name,
       f.flight_no,
       b.fare,
       (SELECT ROUND(AVG(b2.fare), 2)
        FROM bookings b2
        INNER JOIN seats s2 ON b2.seat_id = s2.seat_id
        WHERE s2.flight_id = s.flight_id) AS flight_avg_fare
FROM bookings b
INNER JOIN passengers p ON b.passenger_id = p.passenger_id
INNER JOIN seats s      ON b.seat_id = s.seat_id
INNER JOIN flights f    ON s.flight_id = f.flight_id
WHERE b.fare > (SELECT AVG(b2.fare)
                FROM bookings b2
                INNER JOIN seats s2 ON b2.seat_id = s2.seat_id
                WHERE s2.flight_id = s.flight_id)
ORDER BY f.flight_no, b.fare DESC;
